#pragma once

enum Instructions : int { GET, PUT, LOAD, STORE, COPY, ADD, SUB, HALF, INC, DEC, JUMP, JZERO, JODD, HALT };

